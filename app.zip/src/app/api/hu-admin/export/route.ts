import { autoCancelExpiredOrders, readStore } from "@/lib/store";
import { NextRequest, NextResponse } from "next/server";
import { isHuAdminRequest } from "@/lib/admin-guard";

export async function GET(request: NextRequest) {
  if (!isHuAdminRequest(request)) {
    return NextResponse.json({ ok: false, message: "Unauthorized" }, { status: 401 });
  }
  await autoCancelExpiredOrders();
  const store = await readStore("HU");

  const header = [
    "order_number",
    "order_id",
    "created_at",
    "name",
    "email",
    "phone",
    "quantity",
    "payment",
    "shipping_carrier",
    "shipping_note",
    "status",
    "total_huf",
    "delivery_address",
    "additional_notes",
  ];
  const rows = store.orders.map((o) => [
    String(o.orderNumber),
    o.id,
    o.createdAt,
    o.customerName,
    o.email,
    o.phone,
    String(o.quantity),
    o.paymentMethod,
    o.shippingCarrier,
    o.shippingCarrierOther?.replaceAll("\n", " ") || "",
    o.status,
    String(o.totalPrice),
    o.deliveryAddress.replaceAll("\n", " "),
    o.additionalNotes?.replaceAll("\n", " ") || "",
  ]);
  const csv = [header, ...rows]
    .map((r) => r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(","))
    .join("\n");

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "attachment; filename=hu-orders.csv",
    },
  });
}
